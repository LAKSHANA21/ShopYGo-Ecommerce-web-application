package com.ecommerce.frontend.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FrontendController {

    @GetMapping("/")
    public String home() {
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "auth/userAuth";
    }

    @GetMapping("/register")
    public String showRegisterPage() {
        return "auth/userRegister";
    }

    @GetMapping("/profile")
    public String showProfilePage() {
        return "user/profile";
    }

    @GetMapping("/profile/edit")
    public String showEditProfilePage() {
        return "user/edit-profile";
    }
}