package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.*;
import com.ecommerce.repository.*;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final OrderItemVariantRepository orderItemVariantRepository;
    private final OrderReviewRepository orderReviewRepository;
    private final CartService cartService;
    private final CartItemService cartItemService;
    private final ProductService productService;
    private final UserService userService;
    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    @Transactional
    public Order placeOrder(Long userId, Long cartId, String shippingAddress) {
        logger.debug("Placing order for userId: {}, cartId: {}", userId, cartId);

        // Validate cart
        Cart cart = cartService.findById(cartId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart not found with id " + cartId));
        if (!cart.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Cart does not belong to user");
        }
        List<CartItem> cartItems = cartItemService.findByCartId(cartId);
        if (cartItems.isEmpty()) {
            throw new IllegalArgumentException("Cart is empty");
        }

        // Create order
        Order order = Order.builder()
                .userId(userId)
                .vendorId(getVendorIdForCartItems(cartItems)) // Simplified: assumes single vendor
                .totalAmount(calculateTotalAmount(cartItems))
                .status(OrderStatus.PLACED)
                .shippingAddress(shippingAddress)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .items(new ArrayList<>())
                .build();

        // Convert cart items to order items
        for (CartItem cartItem : cartItems) {
            Product product = productService.findById(cartItem.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + cartItem.getProductId()));
            
            OrderItem orderItem = OrderItem.builder()
                    .order(order)
                    .productId(cartItem.getProductId())
                    .quantity(cartItem.getQuantity())
                    .unitPrice(product.getSellingPrice()) // Assume Product has getPrice()
                    .selectedVariants(new ArrayList<>())
                    .build();

            // Copy variants
            for (CartItemVariant cartVariant : cartItem.getSelectedVariants()) {
                OrderItemVariant orderVariant = OrderItemVariant.builder()
                        .orderItem(orderItem)
                        .variantId(cartVariant.getVariantId())
                        .variantValueId(cartVariant.getVariantValueId())
                        .build();
                orderItem.getSelectedVariants().add(orderVariant);
            }

            order.getItems().add(orderItem);
        }

        Order savedOrder = orderRepository.save(order);
        // Clear cart
        cartItemService.findByCartId(cartId).forEach(item -> 
            cartItemService.deleteCartItem(cartId, item.getId()));
        
        logger.info("Order placed with id: {} for user: {}", savedOrder.getId(), userId);
        return savedOrder;
    }

    public List<Order> getUserOrders(Long userId) {
        logger.debug("Fetching orders for userId: {}", userId);
        return orderRepository.findByUserId(userId);
    }

    public List<Order> getVendorOrders(Long vendorId) {
        logger.debug("Fetching orders for vendorId: {}", vendorId);
        return orderRepository.findByVendorId(vendorId);
    }

    @Transactional
    public Order updateOrderStatus(Long orderId, OrderStatus status, Long vendorId) {
        logger.debug("Updating status for orderId: {} to {}", orderId, status);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
        if (!order.getVendorId().equals(vendorId)) {
            throw new ResourceNotFoundException("Order does not belong to vendor");
        }
        // Validate status transition
        if (!isValidStatusTransition(order.getStatus(), status)) {
            throw new IllegalArgumentException("Invalid status transition from " + order.getStatus() + " to " + status);
        }
        order.setStatus(status);
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }

    @Transactional
    public Order cancelOrder(Long orderId, Long userId) {
        logger.debug("Cancelling orderId: {} for userId: {}", orderId, userId);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
        if (!order.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Order does not belong to user");
        }
        if (order.getStatus() != OrderStatus.PLACED && order.getStatus() != OrderStatus.PROCESSING) {
            throw new IllegalArgumentException("Order cannot be cancelled in status: " + order.getStatus());
        }
        order.setStatus(OrderStatus.CANCELLED);
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }

    @Transactional
    public Order requestReturn(Long orderId, Long userId) {
        logger.debug("Requesting return for orderId: {} by userId: {}", orderId, userId);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
        if (!order.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Order does not belong to user");
        }
        if (order.getStatus() != OrderStatus.DELIVERED) {
            throw new IllegalArgumentException("Return can only be requested for delivered orders");
        }
        order.setStatus(OrderStatus.RETURN_REQUESTED);
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }

    @Transactional
    public Order requestReplacement(Long orderId, Long userId) {
        logger.debug("Requesting replacement for orderId: {} by userId: {}", orderId, userId);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
        if (!order.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Order does not belong to user");
        }
        if (order.getStatus() != OrderStatus.DELIVERED) {
            throw new IllegalArgumentException("Replacement can only be requested for delivered orders");
        }
        order.setStatus(OrderStatus.REPLACEMENT_REQUESTED);
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }

    @Transactional
    public Order handleReturn(Long orderId, Long vendorId, boolean approve) {
        logger.debug("Handling return for orderId: {} by vendorId: {}, approve: {}", orderId, vendorId, approve);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
        if (!order.getVendorId().equals(vendorId)) {
            throw new ResourceNotFoundException("Order does not belong to vendor");
        }
        if (order.getStatus() != OrderStatus.RETURN_REQUESTED) {
            throw new IllegalArgumentException("Order is not in return requested status");
        }
        order.setStatus(approve ? OrderStatus.RETURNED : OrderStatus.DELIVERED);
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }

    @Transactional
    public OrderReview addReview(Long orderId, Long userId, Integer rating, String comment) {
        logger.debug("Adding review for orderId: {} by userId: {}", orderId, userId);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
        if (!order.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Order does not belong to user");
        }
        if (order.getStatus() != OrderStatus.DELIVERED && order.getStatus() != OrderStatus.RETURNED) {
            throw new IllegalArgumentException("Reviews can only be added for delivered or returned orders");
        }
        if (orderReviewRepository.existsByOrderId(orderId)) {
            throw new IllegalArgumentException("Order already has a review");
        }
        OrderReview review = OrderReview.builder()
                .order(order)
                .rating(rating)
                .comment(comment)
                .createdAt(LocalDateTime.now())
                .build();
        return orderReviewRepository.save(review);
    }

    public byte[] generateInvoice(Long orderId, Long userId) {
        logger.debug("Generating invoice for orderId: {} by userId: {}", orderId, userId);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));
        if (!order.getUserId().equals(userId) && !order.getVendorId().equals(userId)) {
            throw new ResourceNotFoundException("Order does not belong to user or vendor");
        }
        // Placeholder for PDF generation (e.g., using iText or OpenPDF)
        return new byte[]{}; // Implement PDF generation logic
    }

    @Transactional
    public OrderAnalytics getVendorAnalytics(Long vendorId, LocalDateTime startDate, LocalDateTime endDate) {
        logger.debug("Generating analytics for vendorId: {} from {} to {}", vendorId, startDate, endDate);
        List<Order> orders = orderRepository.findByVendorId(vendorId).stream()
                .filter(order -> !order.getCreatedAt().isBefore(startDate) && !order.getCreatedAt().isAfter(endDate))
                .collect(Collectors.toList());

        BigDecimal totalSales = orders.stream()
                .filter(order -> order.getStatus() == OrderStatus.DELIVERED)
                .map(Order::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        long orderCount = orders.size();
        long deliveredCount = orders.stream()
                .filter(order -> order.getStatus() == OrderStatus.DELIVERED)
                .count();

        return OrderAnalytics.builder()
                .vendorId(vendorId)
                .totalSales(totalSales)
                .orderCount(orderCount)
                .deliveredCount(deliveredCount)
                .build();
    }

    private BigDecimal calculateTotalAmount(List<CartItem> cartItems) {
        return cartItems.stream()
                .map(item -> {
                    Product product = productService.findById(item.getProductId())
                            .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + item.getProductId()));
                    return product.getSellingPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private Long getVendorIdForCartItems(List<CartItem> cartItems) {
        // Simplified: assume all items belong to the same vendor
        Long productId = cartItems.get(0).getProductId();
        Product product = productService.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + productId));
        return product.getSellerId(); // Assume Product has getVendorId()
    }

    private boolean isValidStatusTransition(OrderStatus current, OrderStatus next) {
        switch (current) {
            case PLACED:
                return next == OrderStatus.PROCESSING || next == OrderStatus.CANCELLED;
            case PROCESSING:
                return next == OrderStatus.SHIPPED || next == OrderStatus.CANCELLED;
            case SHIPPED:
                return next == OrderStatus.DELIVERED;
            case DELIVERED:
                return next == OrderStatus.RETURN_REQUESTED || next == OrderStatus.REPLACEMENT_REQUESTED;
            case RETURN_REQUESTED:
                return next == OrderStatus.RETURNED || next == OrderStatus.DELIVERED;
            case REPLACEMENT_REQUESTED:
                return next == OrderStatus.REPLACED || next == OrderStatus.DELIVERED;
            default:
                return false;
        }
    }
}

