package com.ecommerce.controller;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Cart;
import com.ecommerce.model.CartItem;
import com.ecommerce.service.CartItemService;
import com.ecommerce.service.CartService;
import com.ecommerce.service.ProductService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;
    private final ProductService productService;
    private final CartItemService cartItemService;
    private final com.ecommerce.service.UserService userService;

    @PostMapping
    public ResponseEntity<Cart> createCart(@RequestBody Cart cart) {
        Long userId = getCurrentUserId();
        cart.setUserId(userId);
        cart.setCreatedAt(LocalDateTime.now());
        cart.setUpdatedAt(LocalDateTime.now());
        Cart savedCart = cartService.save(cart);
        return ResponseEntity.ok(savedCart);
    }

    @PostMapping("/{cartId}/items")
    public ResponseEntity<CartItem> addToCart(
            @PathVariable Long cartId,
            @RequestBody CartItem cartItem) {
        Optional<Cart> cartOpt = cartService.findById(cartId);
        if (cartOpt.isEmpty()) {
            throw new ResourceNotFoundException("Cart not found with id " + cartId);
        }
        Long userId = getCurrentUserId();
        if (!cartOpt.get().getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Cart does not belong to user");
        }
        if (productService.findById(cartItem.getProductId()).isEmpty()) {
            throw new ResourceNotFoundException("Product not found with id " + cartItem.getProductId());
        }
        cartItem.setCartId(cartId);
        cartItem.setCreatedAt(LocalDateTime.now());
        cartItem.setUpdatedAt(LocalDateTime.now());
        CartItem savedCartItem = cartItemService.save(cartItem);
        return ResponseEntity.ok(savedCartItem);
    }

    @GetMapping("/{cartId}")
    public ResponseEntity<Cart> getCart(@PathVariable Long cartId) {
        Optional<Cart> cartOpt = cartService.findById(cartId);
        if (cartOpt.isEmpty()) {
            throw new ResourceNotFoundException("Cart not found with id " + cartId);
        }
        Long userId = getCurrentUserId();
        if (!cartOpt.get().getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Cart does not belong to user");
        }
        return ResponseEntity.ok(cartOpt.get());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<Cart> getCartByUserId(@PathVariable Long userId) {
        Long authenticatedUserId = getCurrentUserId();
        if (!userId.equals(authenticatedUserId)) {
            throw new ResourceNotFoundException("Unauthorized access to cart");
        }
        Optional<Cart> cartOpt = cartService.findByUserId(userId);
        if (cartOpt.isEmpty()) {
            Cart newCart = new Cart();
            newCart.setUserId(userId);
            newCart.setCreatedAt(LocalDateTime.now());
            newCart.setUpdatedAt(LocalDateTime.now());
            Cart savedCart = cartService.save(newCart);
            return ResponseEntity.ok(savedCart);
        }
        return ResponseEntity.ok(cartOpt.get());
    }

    @GetMapping("/{cartId}/items")
    public ResponseEntity<List<CartItem>> getCartItems(@PathVariable Long cartId) {
        if (cartService.findById(cartId).isEmpty()) {
            throw new ResourceNotFoundException("Cart not found with id " + cartId);
        }
        Long userId = getCurrentUserId();
        if (!cartService.findById(cartId).get().getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Cart does not belong to user");
        }
        List<CartItem> cartItems = cartItemService.findByCartId(cartId);
        return ResponseEntity.ok(cartItems);
    }

    @DeleteMapping("/{cartId}/items/{itemId}")
    @Transactional
    public ResponseEntity<Void> deleteCartItem(
            @PathVariable Long cartId,
            @PathVariable Long itemId) {
        Cart cart = cartService.findById(cartId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart not found with id " + cartId));
        Long userId = getCurrentUserId();
        if (!cart.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Cart does not belong to user");
        }
        cartItemService.deleteCartItem(cartId, itemId);
        return ResponseEntity.noContent().build();
    }

    // NEW: Endpoint to update cart item quantity
    @PutMapping("/{cartId}/items/{itemId}")
    @Transactional
    public ResponseEntity<CartItem> updateCartItemQuantity(
            @PathVariable Long cartId,
            @PathVariable Long itemId,
            @RequestBody CartItemUpdateRequest updateRequest) {
        // Validate cart existence
        Cart cart = cartService.findById(cartId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart not found with id " + cartId));
        // Verify cart belongs to authenticated user
        Long userId = getCurrentUserId();
        if (!cart.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Cart does not belong to user");
        }
        // Update quantity
        CartItem updatedItem = cartItemService.updateQuantity(cartId, itemId, updateRequest.getQuantity());
        return ResponseEntity.ok(updatedItem);
    }

    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new ResourceNotFoundException("User not authenticated");
        }
        String username;
        Object principal = authentication.getPrincipal();
        if (principal instanceof UserDetails) {
            username = ((UserDetails) principal).getUsername();
        } else if (principal instanceof String) {
            username = (String) principal;
        } else {
            throw new IllegalStateException("Unexpected principal type: " + principal.getClass());
        }
        return userService.findByEmailOrMobile(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with username: " + username))
                .getId();
    }

    // NEW: DTO for quantity update request
    public static class CartItemUpdateRequest {
        private int quantity;

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }
}