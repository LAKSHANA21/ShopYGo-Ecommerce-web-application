package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Cart;
import com.ecommerce.model.CartItem;
import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final CartService cartService;
    private final CartItemService cartItemService;

    @Transactional
    public Order createOrder(Long userId, Long cartId) {
        Cart cart = cartService.findById(cartId)
            .orElseThrow(() -> new ResourceNotFoundException("Cart not found with id " + cartId));
        if (!cart.getUserId().equals(userId)) {
            throw new IllegalArgumentException("Cart does not belong to user");
        }
        List<CartItem> cartItems = cartItemService.findByCartId(cartId);
        if (cartItems.isEmpty()) {
            throw new IllegalStateException("Cart is empty");
        }

        // Temporary: Hardcode sellerId and unitPrice until ProductService is defined
        Long sellerId = 1L; // Replace with actual seller ID or fetch from ProductService
        Double defaultUnitPrice = 100.0; // Replace with actual price logic

        Order order = new Order();
        order.setUserId(userId);
        order.setSellerId(sellerId);
        order.setStatus("PENDING");
        order.setCreatedAt(LocalDateTime.now());
        order.setUpdatedAt(LocalDateTime.now());

        List<OrderItem> orderItems = cartItems.stream().map(cartItem -> {
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setProductId(cartItem.getProductId());
            orderItem.setVariantId(cartItem.getVariantId());
            orderItem.setVariantValueId(cartItem.getVariantValueId());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setUnitPrice(defaultUnitPrice);
            return orderItem;
        }).collect(Collectors.toList());

        order.setOrderItems(orderItems);
        order.setTotalAmount(orderItems.stream()
            .mapToDouble(item -> item.getQuantity() * item.getUnitPrice())
            .sum());

        Order savedOrder = orderRepository.save(order);
        cartItems.forEach(item -> cartItemService.deleteCartItem(cartId, item.getId()));
        return savedOrder;
    }

    public List<Order> findOrdersBySellerId(Long sellerId) {
        return orderRepository.findBySellerId(sellerId);
    }
}