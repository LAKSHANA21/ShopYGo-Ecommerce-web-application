package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.CartItem;
import com.ecommerce.repository.CartItemRepository;
import com.ecommerce.repository.ProductVariantRepository;
import com.ecommerce.repository.ProductVariantValueRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CartItemService {

    private final CartItemRepository cartItemRepository;
    private final ProductVariantRepository productVariantRepository;
    private final ProductVariantValueRepository productVariantValueRepository;
    private static final Logger logger = LoggerFactory.getLogger(CartItemService.class);

    @Transactional
    public CartItem save(CartItem cartItem) {
        logger.debug("Saving cart item for productId: {}, variantId: {}, variantValueId: {}",
                cartItem.getProductId(), cartItem.getVariantId(), cartItem.getVariantValueId());

        boolean hasVariants = productVariantRepository.existsByProductId(cartItem.getProductId());
        logger.debug("Product {} has variants: {}", cartItem.getProductId(), hasVariants);

        if (hasVariants) {
            if (cartItem.getVariantId() == null || cartItem.getVariantValueId() == null) {
                logger.error("Variant and variant value required for product {}", cartItem.getProductId());
                throw new IllegalArgumentException("Variant and variant value are required for this product");
            }
            if (!productVariantRepository.existsById(cartItem.getVariantId())) {
                logger.error("Variant not found with id {}", cartItem.getVariantId());
                throw new ResourceNotFoundException("Variant not found with id " + cartItem.getVariantId());
            }
            if (!productVariantRepository.existsByIdAndProductId(cartItem.getVariantId(), cartItem.getProductId())) {
                logger.error("Variant {} does not belong to product {}", cartItem.getVariantId(), cartItem.getProductId());
                throw new ResourceNotFoundException("Variant " + cartItem.getVariantId() + " does not belong to product " + cartItem.getProductId());
            }
            if (!productVariantValueRepository.existsById(cartItem.getVariantValueId())) {
                logger.error("Variant value not found with id {}", cartItem.getVariantValueId());
                throw new ResourceNotFoundException("Variant value not found with id " + cartItem.getVariantValueId());
            }
            if (!productVariantValueRepository.existsByIdAndVariantId(cartItem.getVariantValueId(), cartItem.getVariantId())) {
                logger.error("Variant value {} does not belong to variant {}", cartItem.getVariantValueId(), cartItem.getVariantId());
                throw new ResourceNotFoundException("Variant value " + cartItem.getVariantValueId() + " does not belong to variant " + cartItem.getVariantId());
            }
        } else {
            if (cartItem.getVariantId() != null || cartItem.getVariantValueId() != null) {
                logger.error("Product {} does not have variants; variantId and variantValueId must be null", cartItem.getProductId());
                throw new IllegalArgumentException("Product does not have variants; variantId and variantValueId must be null");
            }
        }

        CartItem savedItem = cartItemRepository.save(cartItem);
        logger.info("Saved cart item with id: {} for cart: {}", savedItem.getId(), cartItem.getCartId());
        return savedItem;
    }

    public List<CartItem> findByCartId(Long cartId) {
        logger.debug("Fetching cart items for cartId: {}", cartId);
        return cartItemRepository.findByCartId(cartId);
    }

    @Transactional
    public void deleteCartItem(Long cartId, Long itemId) {
        logger.debug("Deleting cart item id: {} from cart: {}", itemId, cartId);
        CartItem item = cartItemRepository.findByIdAndCartId(itemId, cartId)
                .orElseThrow(() -> {
                    logger.error("Cart item not found with id {} in cart {}", itemId, cartId);
                    return new ResourceNotFoundException("Cart item not found with id " + itemId + " in cart " + cartId);
                });
        cartItemRepository.delete(item);
        logger.info("Deleted cart item id: {} from cart: {}", itemId, cartId);
    }

    // NEW: Method to update cart item quantity
    @Transactional
    public CartItem updateQuantity(Long cartId, Long itemId, int quantity) {
        logger.debug("Updating quantity for cart item id: {} in cart: {} to {}", itemId, cartId, quantity);
        
        // Validate quantity
        if (quantity < 1) {
            logger.error("Quantity must be at least 1 for cart item id: {}", itemId);
            throw new IllegalArgumentException("Quantity must be at least 1");
        }

        // Find the cart item
        CartItem item = cartItemRepository.findByIdAndCartId(itemId, cartId)
                .orElseThrow(() -> {
                    logger.error("Cart item not found with id {} in cart {}", itemId, cartId);
                    return new ResourceNotFoundException("Cart item not found with id " + itemId + " in cart " + cartId);
                });

        // Update quantity and timestamp
        item.setQuantity(quantity);
        item.setUpdatedAt(LocalDateTime.now());

        // Save updated item
        CartItem updatedItem = cartItemRepository.save(item);
        logger.info("Updated cart item id: {} in cart: {} with quantity: {}", itemId, cartId, quantity);
        return updatedItem;
    }
}