package com.ecommerce.repository;

import com.ecommerce.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CategoryRepository extends JpaRepository<Category, Long> {
	List<Category> findByParentCategoryIsNull();
    List<Category> findByParentCategorySequenceId(Long parentSequenceId);

}