package com.ecommerce.controller;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Product;
import com.ecommerce.payload.ApiResponse;
import com.ecommerce.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/wishlist")
@RequiredArgsConstructor
public class WishlistController {

    private final ProductService productService;

    // In-memory wishlist (replace with database in production)
    private final List<Long> wishlist = new ArrayList<>();

    @PostMapping("/{productId}")
    public ResponseEntity<?> addToWishlist(@PathVariable Long productId) {
        Optional<Product> productOpt = productService.findById(productId);
        if (productOpt.isEmpty()) {
            throw new ResourceNotFoundException("Product not found with id " + productId);
        }
        if (!wishlist.contains(productId)) {
            wishlist.add(productId);
        }
        return ResponseEntity.ok(new ApiResponse(true, "Product added to wishlist"));
    }

    @GetMapping
    public ResponseEntity<List<Product>> getWishlist() {
        List<Product> products = wishlist.stream()
                .map(productService::findById)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toList());
        return ResponseEntity.ok(products);
    }

    @DeleteMapping("/{productId}")
    public ResponseEntity<?> removeFromWishlist(@PathVariable Long productId) {
        wishlist.remove(productId);
        return ResponseEntity.ok(new ApiResponse(true, "Product removed from wishlist"));
    }
}