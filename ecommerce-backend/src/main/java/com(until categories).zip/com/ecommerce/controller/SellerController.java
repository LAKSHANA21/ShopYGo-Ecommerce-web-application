package com.ecommerce.controller;

import com.ecommerce.model.Seller;
import com.ecommerce.model.SellerStatus;
import com.ecommerce.payload.ApiResponse;
import com.ecommerce.service.SellerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sellers")
@RequiredArgsConstructor
public class SellerController {

    private final SellerService sellerService;

    @PostMapping("/create")
    public ResponseEntity<Seller> addSeller(@RequestBody Seller seller) {
        Seller createdSeller = sellerService.addSeller(seller);
        return ResponseEntity.ok(createdSeller);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Seller> getSellerById(@PathVariable Long id) {
        Seller seller = sellerService.getSellerById(id);
        return ResponseEntity.ok(seller);
    }

    @GetMapping
    public ResponseEntity<List<Seller>> getAllSellers() {
        List<Seller> sellers = sellerService.getAllSellers();
        return ResponseEntity.ok(sellers);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Seller> updateSeller(@PathVariable Long id, @RequestBody Seller seller) {
        Seller updatedSeller = sellerService.updateSeller(id, seller);
        return ResponseEntity.ok(updatedSeller);
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse> updateSellerStatus(@PathVariable Long id, @RequestParam("status") String status) {
        try {
            SellerStatus sellerStatus = SellerStatus.valueOf(status.toUpperCase());
            sellerService.updateSellerStatus(id, sellerStatus);
            return ResponseEntity.ok(new ApiResponse(true, "Seller status updated successfully."));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(new ApiResponse(false, "Invalid status value."));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteSeller(@PathVariable Long id) {
        sellerService.deleteSeller(id);
        return ResponseEntity.ok(new ApiResponse(true, "Seller deleted successfully"));
    }

    @GetMapping("/{id}/dashboard")
    public ResponseEntity<?> getSellerDashboard(@PathVariable Long id) {
        Map<String, Object> dashboardData = Map.of(
            "totalOrders", 25,
            "pendingOrders", 5,
            "completedOrders", 20,
            "totalRevenue", 15000
        );
        return ResponseEntity.ok(dashboardData);
    }
}