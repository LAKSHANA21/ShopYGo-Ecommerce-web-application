package com.ecommerce.controller;

import com.ecommerce.model.Admin;
import com.ecommerce.model.Seller;
import com.ecommerce.model.User;
import com.ecommerce.payload.AdminSignupRequest;
import com.ecommerce.payload.ApiResponse;
import com.ecommerce.payload.JwtAuthenticationResponse;
import com.ecommerce.payload.LoginRequest;
import com.ecommerce.payload.SellerSignupRequest;
import com.ecommerce.payload.UserSignupRequest;
import com.ecommerce.security.JwtTokenProvider;
import com.ecommerce.service.AdminService;
import com.ecommerce.service.SellerService;
import com.ecommerce.service.SmsService;
import com.ecommerce.service.EmailService;
import com.ecommerce.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin("*")
public class AuthController {

    private final UserService userService;
    private final SellerService sellerService;
    private final AdminService adminService;
    private final JwtTokenProvider tokenProvider;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    private final SmsService smsService;

    private static final Map<String, String> otpCache = new ConcurrentHashMap<>();

    @PostMapping("/userRegister")
    public ResponseEntity<ApiResponse> registerUser(@RequestBody UserSignupRequest signupRequest) {
        if (userService.existsByEmail(signupRequest.getEmail())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(false, "Email is already in use"));
        }

        User user = User.builder()
                .firstName(signupRequest.getFirstName())
                .lastName(signupRequest.getLastName())
                .email(signupRequest.getEmail())
                .password(passwordEncoder.encode(signupRequest.getPassword()))
                .phone(signupRequest.getPhone())
                .role("USER")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .addressLine1(signupRequest.getAddressLine1())
                .addressLine2(signupRequest.getAddressLine2())
                .city(signupRequest.getCity())
                .state(signupRequest.getState())
                .postalCode(signupRequest.getPostalCode())
                .country(signupRequest.getCountry())
                .dob(signupRequest.getDob())
                .gender(signupRequest.getGender())
                .build();

        userService.save(user);
        return ResponseEntity.ok(new ApiResponse(true, "User registered successfully"));
    }

    @PostMapping("/sellerRegister")
    public ResponseEntity<ApiResponse> registerSeller(@RequestBody SellerSignupRequest signupRequest) {
        // Check email uniqueness across all tables for consistency
        if (userService.existsByEmail(signupRequest.getEmail()) || 
            sellerService.findByEmailOrMobile(signupRequest.getEmail()).isPresent() || 
            adminService.existsByEmail(signupRequest.getEmail())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(false, "Email is already in use"));
        }

        Seller seller = Seller.builder()
                .firstName(signupRequest.getFirstName())
                .lastName(signupRequest.getLastName())
                .email(signupRequest.getEmail())
                .password(passwordEncoder.encode(signupRequest.getPassword()))
                .phone(signupRequest.getPhone())
                .role("SELLER")
                .storeName(signupRequest.getStoreName())
                .businessDetails(signupRequest.getBusinessDetails())
                .addressLine1(signupRequest.getAddressLine1())
                .addressLine2(signupRequest.getAddressLine2())
                .city(signupRequest.getCity())
                .state(signupRequest.getState())
                .postalCode(signupRequest.getPostalCode())
                .country(signupRequest.getCountry())
                .contactNumber(signupRequest.getContactNumber())
                .gstNumber(signupRequest.getGstNumber())
                .bankDetails(signupRequest.getBankDetails())
                .businessEmail(signupRequest.getBusinessEmail())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        sellerService.addSeller(seller);
        return ResponseEntity.ok(new ApiResponse(true, "Seller registered successfully"));
    }

    @PostMapping("/adminRegister")
    public ResponseEntity<ApiResponse> registerAdmin(@RequestBody AdminSignupRequest signupRequest) {
        if (adminService.existsByEmail(signupRequest.getEmail())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(false, "Email is already in use"));
        }

        Admin admin = Admin.builder()
                .firstName(signupRequest.getFirstName())
                .lastName(signupRequest.getLastName())
                .email(signupRequest.getEmail())
                .password(passwordEncoder.encode(signupRequest.getPassword()))
                .role("ADMIN")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        adminService.addAdmin(admin);
        return ResponseEntity.ok(new ApiResponse(true, "Admin registered successfully"));
    }

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
        Optional<User> userOptional = userService.findByEmailOrMobile(loginRequest.getIdentifier());
        Optional<Admin> adminOptional = adminService.findByEmail(loginRequest.getIdentifier());
        Optional<Seller> sellerOptional = sellerService.findByEmailOrMobile(loginRequest.getIdentifier());

        if (userOptional.isEmpty() && adminOptional.isEmpty() && sellerOptional.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse(false, "Invalid identifier"));
        }

        String email = loginRequest.getIdentifier();
        String password = null;
        String role = null;
        long userId = 0;

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            email = user.getEmail();
            password = user.getPassword();
            role = user.getRole();
            userId = user.getId();
        } else if (adminOptional.isPresent()) {
            Admin admin = adminOptional.get();
            email = admin.getEmail();
            password = admin.getPassword();
            role = admin.getRole();
            userId = admin.getId();
        } else if (sellerOptional.isPresent()) {
            Seller seller = sellerOptional.get();
            email = seller.getEmail();
            password = seller.getPassword();
            role = seller.getRole();
            userId = seller.getId();
        }

        if (loginRequest.getOtp() != null && !loginRequest.getOtp().isEmpty()) {
            String cachedOtp = otpCache.get(loginRequest.getIdentifier());
            if (cachedOtp == null || !cachedOtp.equals(loginRequest.getOtp())) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse(false, "Invalid OTP"));
            }
            otpCache.remove(loginRequest.getIdentifier());
        } else if (loginRequest.getPassword() != null && !loginRequest.getPassword().isEmpty()) {
            if (!passwordEncoder.matches(loginRequest.getPassword(), password)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse(false, "Invalid password"));
            }
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(false, "Authentication credential required"));
        }

        Map<String, Object> claims = new HashMap<>();
        claims.put("role", role);

        String accessToken = tokenProvider.generateAccessToken(email, claims);
        String refreshToken = tokenProvider.generateRefreshToken(email);
        
        return ResponseEntity.ok(new JwtAuthenticationResponse(accessToken, refreshToken,  userId));
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<?> refreshAccessToken(@RequestBody Map<String, String> request) {
        String refreshToken = request.get("refreshToken");
        if (tokenProvider.validateToken(refreshToken)) {
            String username = tokenProvider.getUsernameFromToken(refreshToken);
            String newAccessToken = tokenProvider.generateAccessToken(username, new HashMap<>());
            Map<String, String> response = new HashMap<>();
            response.put("accessToken", newAccessToken);
            response.put("refreshToken", refreshToken);
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(new ApiResponse(false, "Invalid Refresh Token"));
        }
    }

    @PostMapping("/request-otp")
    public ResponseEntity<ApiResponse> requestOtp(@RequestParam String identifier) {
        String otp = String.valueOf(100000 + (int)(Math.random() * 900000));
        otpCache.put(identifier, otp);

        if (identifier.contains("@")) {
            emailService.sendSimpleMessage(identifier, "Your OTP Code", "Your OTP is: " + otp);
        } else {
            smsService.sendSms(identifier, "Your OTP is: " + otp);
        }

        return ResponseEntity.ok(new ApiResponse(true, "OTP sent successfully"));
    }
}