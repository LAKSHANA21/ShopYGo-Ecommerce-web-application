package com.ecommerce.controller;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.User;
import com.ecommerce.payload.ApiResponse;
import com.ecommerce.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // Create a new user (including profile fields)
    @PostMapping("/create")
    public ResponseEntity<User> createUser(@RequestBody User user) {
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        User createdUser = userService.save(user);
        return ResponseEntity.ok(createdUser);
    }

    // Retrieve a user by ID
    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable Long id) {
        Optional<User> userOpt = userService.findById(id);
        if (userOpt.isEmpty()) {
            throw new ResourceNotFoundException("User not found with id " + id);
        }
        return ResponseEntity.ok(userOpt.get());
    }

    // Update an existing user (including profile details)
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User updatedUser) {
        Optional<User> userOpt = userService.findById(id);
        if (userOpt.isEmpty()) {
            throw new ResourceNotFoundException("User not found with id " + id);
        }
        User user = userOpt.get();
        // Update basic info
        user.setFirstName(updatedUser.getFirstName());
        user.setLastName(updatedUser.getLastName());
        user.setEmail(updatedUser.getEmail());
        user.setPhone(updatedUser.getPhone());
        // Update profile fields
        user.setAddressLine1(updatedUser.getAddressLine1());
        user.setAddressLine2(updatedUser.getAddressLine2());
        user.setCity(updatedUser.getCity());
        user.setState(updatedUser.getState());
        user.setPostalCode(updatedUser.getPostalCode());
        user.setCountry(updatedUser.getCountry());
        user.setDob(updatedUser.getDob());
        user.setGender(updatedUser.getGender());
        user.setUpdatedAt(LocalDateTime.now());
        User savedUser = userService.save(user);
        return ResponseEntity.ok(savedUser);
    }

    // Delete a user by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteUser(@PathVariable Long id) {
        userService.delete(id);
        return ResponseEntity.ok(new ApiResponse(true, "User deleted successfully"));
    }

    // Retrieve all users
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.findAll();
        return ResponseEntity.ok(users);
    }
}
