package com.ecommerce.controller;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Cart;
import com.ecommerce.model.CartItem;
import com.ecommerce.service.CartItemService; // New service
import com.ecommerce.service.CartService;
import com.ecommerce.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;

@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;
    private final ProductService productService;
    private final CartItemService cartItemService; // Added dependency

    @PostMapping
    public ResponseEntity<Cart> createCart(@RequestBody Cart cart) {
        cart.setCreatedAt(LocalDateTime.now());
        cart.setUpdatedAt(LocalDateTime.now());
        Cart savedCart = cartService.save(cart);
        return ResponseEntity.ok(savedCart);
    }

    @PostMapping("/{cartId}/items")
    public ResponseEntity<CartItem> addToCart(
            @PathVariable Long cartId,
            @RequestBody CartItem cartItem) {
        // Validate cart existence
        Optional<Cart> cartOpt = cartService.findById(cartId);
        if (cartOpt.isEmpty()) {
            throw new ResourceNotFoundException("Cart not found with id " + cartId);
        }
        // Validate product existence
        if (productService.findById(cartItem.getProductId()).isEmpty()) {
            throw new ResourceNotFoundException("Product not found with id " + cartItem.getProductId());
        }
        cartItem.setCartId(cartId);
        cartItem.setCreatedAt(LocalDateTime.now());
        cartItem.setUpdatedAt(LocalDateTime.now());
        CartItem savedCartItem = cartItemService.save(cartItem); // Save using CartItemService
        return ResponseEntity.ok(savedCartItem);
    }

    @GetMapping("/{cartId}")
    public ResponseEntity<Cart> getCart(@PathVariable Long cartId) {
        Optional<Cart> cartOpt = cartService.findById(cartId);
        if (cartOpt.isEmpty()) {
            throw new ResourceNotFoundException("Cart not found with id " + cartId);
        }
        return ResponseEntity.ok(cartOpt.get());
    }
}