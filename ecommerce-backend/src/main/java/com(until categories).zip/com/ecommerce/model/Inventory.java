package com.ecommerce.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "inventory")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Inventory {
    @Id
    private Long productId;

    @Column(nullable = true)
    private Long variantId;
    private Integer quantity;
    private Integer lowStockThreshold;

    private LocalDateTime updatedAt;
}