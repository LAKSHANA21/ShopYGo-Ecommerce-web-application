package com.ecommerce.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "seller")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Seller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Basic Seller Fields (previously in User)
    private String firstName;
    private String lastName;
    @Column(unique = true)
    private String email;
    private String password;
    private String phone;

    // Set role to "SELLER" by default
    @Builder.Default
    private String role = "SELLER";

    // Seller-specific details
    private String storeName;
    private String businessDetails;

    // Address fields
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String postalCode;
    private String country;

    private String contactNumber;
    private String gstNumber;      // GST Number for Tax Compliance
    private String bankDetails;
    private String businessEmail;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private SellerStatus status = SellerStatus.PENDING; // Default to PENDING

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}