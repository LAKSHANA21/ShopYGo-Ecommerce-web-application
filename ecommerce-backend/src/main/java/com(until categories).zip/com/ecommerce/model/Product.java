package com.ecommerce.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "products")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long sellerId;

    private String name;
    private BigDecimal actualPrice;
    @Column(nullable = true)
    private String thumbnailUrl;

    private String description;
    private BigDecimal mrp;
    private BigDecimal margin;
    @Column(nullable = false, columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean isActive;

    @ManyToOne
    @JoinColumn(name = "category_sequence_id", referencedColumnName = "sequence_id")
    private Category category;

    @OneToMany(mappedBy = "productId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ProductImage> images;

    @OneToMany(mappedBy = "productId", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ProductVariant> variants;

    @OneToOne
    @JoinColumn(name = "product_id")
    private Inventory inventory;

    @Column(nullable = true)
    private Float averageRating;
    @Column(nullable = true)
    private Integer reviewCount;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}