package com.ecommerce.model;

public enum SellerStatus {
    ACTIVE,     // Seller is active and can list products
    PENDING,    // Seller is awaiting approval
    SUSPENDED   // Seller is suspended and cannot list products
}
