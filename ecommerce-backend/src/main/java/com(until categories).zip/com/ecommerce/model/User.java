package com.ecommerce.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    // Basic User Fields
    private String firstName;
    private String lastName;
    
    @Column(unique = true)
    private String email;
    private String password;
    private String phone;
    
    // Role is defaulted to "USER" but can be overridden in seller endpoints.
    @Builder.Default
    private String role = "USER";
    
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    // Profile Fields
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String postalCode;
    private String country;
    private LocalDate dob;
    private String gender;
    
    @Column(nullable = false)
    @Builder.Default
    private Boolean verified = false; // Default to false for new users
}
