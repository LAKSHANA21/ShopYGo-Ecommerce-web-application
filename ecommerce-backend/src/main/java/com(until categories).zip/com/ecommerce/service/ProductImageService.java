package com.ecommerce.service;

import com.ecommerce.model.ProductImage;
import com.ecommerce.repository.ProductImageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductImageService {

    private final ProductImageRepository productImageRepository;

    public List<ProductImage> findAll() {
        return productImageRepository.findAll();
    }

    public Optional<ProductImage> findById(Long id) {
        return productImageRepository.findById(id);
    }

    public List<ProductImage> findByProductId(Long productId) {
        return productImageRepository.findAll().stream()
                .filter(img -> img.getProductId().equals(productId))
                .collect(Collectors.toList());
    }

    public ProductImage save(ProductImage productImage) {
        return productImageRepository.save(productImage);
    }

    public void deleteById(Long id) {
        productImageRepository.deleteById(id);
    }
}