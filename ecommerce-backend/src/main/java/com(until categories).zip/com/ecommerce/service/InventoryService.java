package com.ecommerce.service;

import com.ecommerce.model.Inventory;
import com.ecommerce.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class InventoryService {

    private final InventoryRepository inventoryRepository;

    public List<Inventory> findAll() {
        return inventoryRepository.findAll();
    }

    public Optional<Inventory> findById(Long productId) {
        return inventoryRepository.findById(productId);
    }

    public Inventory updateStock(Long productId, Integer quantity) {
        Optional<Inventory> inventoryOpt = findById(productId);
        Inventory inventory = inventoryOpt.orElse(new Inventory());
        inventory.setProductId(productId);
        inventory.setQuantity(quantity);
        inventory.setUpdatedAt(LocalDateTime.now());
        return inventoryRepository.save(inventory);
    }

    public long countLowStock() {
        return inventoryRepository.findAll().stream()
                .filter(i -> i.getQuantity() <= i.getLowStockThreshold())
                .count();
    }
}