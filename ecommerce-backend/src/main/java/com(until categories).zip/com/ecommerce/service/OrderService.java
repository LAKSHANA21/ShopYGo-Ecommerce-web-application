package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.repository.OrderItemRepository;
import com.ecommerce.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;

    public List<Order> findAll() {
        return orderRepository.findAll();
    }

    public Optional<Order> findById(Long id) {
        return orderRepository.findById(id);
    }

    public Order save(Order order) {
        return orderRepository.save(order);
    }

    public long countByStatus(String status) {
        return orderRepository.findAll().stream()
                .filter(order -> order.getOrderStatus().equalsIgnoreCase(status))
                .count();
    }

    public List<Order> findByStatus(String status) {
        return orderRepository.findAll().stream()
                .filter(order -> order.getOrderStatus().equalsIgnoreCase(status))
                .toList();
    }

    public void updateShippingStatus(Long orderId, Long itemId, String shippingStatus) {
        Optional<Order> orderOpt = findById(orderId);
        if (orderOpt.isEmpty()) {
            throw new ResourceNotFoundException("Order not found with id " + orderId);
        }
        Optional<OrderItem> itemOpt = orderItemRepository.findById(itemId);
        if (itemOpt.isEmpty() || !itemOpt.get().getOrderId().equals(orderId)) {
            throw new ResourceNotFoundException("Order item not found with id " + itemId + " for order " + orderId);
        }
        OrderItem item = itemOpt.get();
        item.setShippingStatus(shippingStatus);
        item.setUpdatedAt(LocalDateTime.now());
        orderItemRepository.save(item);
    }
}