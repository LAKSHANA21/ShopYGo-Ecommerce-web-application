package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Category;
import com.ecommerce.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CategoryService {

    private final CategoryRepository categoryRepository;

    public List<Category> findAllRootCategories() {
        return categoryRepository.findByParentCategoryIsNull();
    }
    
    public Optional<Category> findById(Long id) {
        return categoryRepository.findById(id);
    }

    public Category save(Category category) {
        return categoryRepository.save(category);
    }

    public void deleteById(Long id) {
        categoryRepository.deleteById(id);
    }

    public Category validateParent(Long parentId) {
        return categoryRepository.findById(parentId)
            .orElseThrow(() -> new ResourceNotFoundException("Parent category not found"));
    }

    public void validateNoCircularReference(Category category, Category potentialParent) {
        if (category.getSequenceId().equals(potentialParent.getSequenceId())) {
            throw new IllegalArgumentException("Category cannot be its own parent");
        }

        Category current = potentialParent.getParentCategory();
        while (current != null) {
            if (current.getSequenceId().equals(category.getSequenceId())) {
                throw new IllegalArgumentException("Circular reference detected");
            }
            current = current.getParentCategory();
        }
    }
 
}