package com.ecommerce.service;

import com.ecommerce.model.ProductVariant;
import com.ecommerce.repository.ProductVariantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductVariantService {

    private final ProductVariantRepository productVariantRepository;

    public List<ProductVariant> findAll() {
        return productVariantRepository.findAll();
    }

    public Optional<ProductVariant> findById(Long id) {
        return productVariantRepository.findById(id);
    }

    public List<ProductVariant> findByProductId(Long productId) {
        return productVariantRepository.findAll().stream()
                .filter(v -> v.getProductId().equals(productId))
                .collect(Collectors.toList());
    }

    public ProductVariant save(ProductVariant productVariant) {
        return productVariantRepository.save(productVariant);
    }

    public void deleteById(Long id) {
        productVariantRepository.deleteById(id);
    }
}