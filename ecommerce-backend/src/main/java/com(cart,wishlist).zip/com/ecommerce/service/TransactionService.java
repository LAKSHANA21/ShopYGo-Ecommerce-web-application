package com.ecommerce.service;

import com.ecommerce.model.Transaction;
import com.ecommerce.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TransactionService {

    private final TransactionRepository transactionRepository;
    
    public List<Transaction> findAll() {
        return transactionRepository.findAll();
    }
    
    public Optional<Transaction> findById(Long id) {
        return transactionRepository.findById(id);
    }
    
    public Transaction save(Transaction transaction) {
        return transactionRepository.save(transaction);
    }
}
