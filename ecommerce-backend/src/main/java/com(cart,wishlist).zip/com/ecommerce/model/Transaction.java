package com.ecommerce.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long orderId;
    private Long userId;
    private Long sellerId;
    private BigDecimal amount;
    private String transactionStatus; // success, failed, pending
    private LocalDateTime transactionDate;
    private LocalDateTime createdAt;
}
