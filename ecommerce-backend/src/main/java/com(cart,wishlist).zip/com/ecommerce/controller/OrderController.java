package com.ecommerce.controller;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Order;
import com.ecommerce.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        List<Order> orders = orderService.findAll();
        return ResponseEntity.ok(orders);
    }

    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        order.setCreatedAt(LocalDateTime.now());
        order.setUpdatedAt(LocalDateTime.now());
        Order savedOrder = orderService.save(order);
        return ResponseEntity.ok(savedOrder);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Order> updateOrder(@PathVariable Long id, @RequestBody Order order) {
        Optional<Order> existingOrderOpt = orderService.findById(id);
        if (existingOrderOpt.isEmpty()) {
            throw new ResourceNotFoundException("Order not found with id " + id);
        }
        Order existingOrder = existingOrderOpt.get();
        existingOrder.setOrderStatus(order.getOrderStatus());
        existingOrder.setPaymentMode(order.getPaymentMode());
        existingOrder.setUpdatedAt(LocalDateTime.now());
        Order updatedOrder = orderService.save(existingOrder);
        return ResponseEntity.ok(updatedOrder);
    }
}
