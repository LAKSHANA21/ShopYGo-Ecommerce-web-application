package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Product;
import com.ecommerce.model.ProductImage;
import com.ecommerce.repository.ProductImageRepository;
import com.ecommerce.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductImageService {

    private final ProductImageRepository productImageRepository;
    private final ProductRepository productRepository;

    public List<ProductImage> findAll() {
        return productImageRepository.findAll();
    }

    public Optional<ProductImage> findById(Long id) {
        return productImageRepository.findById(id);
    }

    public List<ProductImage> findByProductId(Long productId) {
        return productImageRepository.findByProductId(productId);
    }

    public ProductImage save(ProductImage productImage, Long sellerId) {
        Product product = productRepository.findById(productImage.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + productImage.getProductId()));
        if (!product.getSellerId().equals(sellerId)) {
            throw new ResourceNotFoundException("You do not have permission to modify images for this product");
        }
        if (productImage.getId() == null) {
            productImage.setCreatedAt(LocalDateTime.now());
        }
        productImage.setUpdatedAt(LocalDateTime.now());
        return productImageRepository.save(productImage);
    }

    public void deleteById(Long id, Long sellerId) {
        ProductImage image = productImageRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Image not found with id " + id));
        Product product = productRepository.findById(image.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + image.getProductId()));
        if (!product.getSellerId().equals(sellerId)) {
            throw new ResourceNotFoundException("You do not have permission to delete this image");
        }
        productImageRepository.deleteById(id);
    }
}