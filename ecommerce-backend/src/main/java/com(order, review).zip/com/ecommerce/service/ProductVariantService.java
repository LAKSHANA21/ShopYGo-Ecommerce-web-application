package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Product;
import com.ecommerce.model.ProductVariant;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.ProductVariantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductVariantService {

    private final ProductVariantRepository productVariantRepository;
    private final ProductRepository productRepository;

    public List<ProductVariant> findAll() {
        return productVariantRepository.findAll();
    }

    public Optional<ProductVariant> findById(Long id) {
        return productVariantRepository.findById(id);
    }

    public List<ProductVariant> findByProductId(Long productId) {
        return productVariantRepository.findByProductId(productId);
    }

    public ProductVariant save(ProductVariant productVariant, Long sellerId) {
        Product product = productRepository.findById(productVariant.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + productVariant.getProductId()));
        if (!product.getSellerId().equals(sellerId)) {
            throw new ResourceNotFoundException("You do not have permission to modify variants for this product");
        }
        if (productVariant.getId() == null) {
            productVariant.setCreatedAt(LocalDateTime.now());
        }
        productVariant.setUpdatedAt(LocalDateTime.now());
        return productVariantRepository.save(productVariant);
    }

    public void deleteById(Long id, Long sellerId) {
        ProductVariant variant = productVariantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Variant not found with id " + id));
        Product product = productRepository.findById(variant.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + variant.getProductId()));
        if (!product.getSellerId().equals(sellerId)) {
            throw new ResourceNotFoundException("You do not have permission to delete this variant");
        }
        productVariantRepository.deleteById(id);
    }
}