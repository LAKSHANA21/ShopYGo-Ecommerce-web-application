// com.ecommerce.service.InventoryService.java
package com.ecommerce.service;

import com.ecommerce.model.Inventory;

public interface InventoryService {
    void updateStock(Long productId, Integer quantity);
    Inventory save(Inventory inventory);
}