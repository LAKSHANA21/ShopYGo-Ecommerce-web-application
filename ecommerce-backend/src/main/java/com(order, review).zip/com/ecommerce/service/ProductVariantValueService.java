package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Product;
import com.ecommerce.model.ProductVariant;
import com.ecommerce.model.ProductVariantValue;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.ProductVariantRepository;
import com.ecommerce.repository.ProductVariantValueRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductVariantValueService {

    private final ProductVariantValueRepository productVariantValueRepository;
    private final ProductVariantRepository productVariantRepository;
    private final ProductRepository productRepository;

    public List<ProductVariantValue> findAll() {
        return productVariantValueRepository.findAll();
    }

    public Optional<ProductVariantValue> findById(Long id) {
        return productVariantValueRepository.findById(id);
    }

    public List<ProductVariantValue> findByVariantId(Long variantId) {
        return productVariantValueRepository.findByVariantId(variantId);
    }

    public ProductVariantValue save(ProductVariantValue value, Long sellerId) {
        ProductVariant variant = productVariantRepository.findById(value.getVariant().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Variant not found with id " + value.getVariant().getId()));
        Product product = productRepository.findById(variant.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + variant.getProductId()));
        if (!product.getSellerId().equals(sellerId)) {
            throw new ResourceNotFoundException("You do not have permission to modify values for this product");
        }
        if (value.getId() == null) {
            value.setCreatedAt(LocalDateTime.now());
        }
        value.setUpdatedAt(LocalDateTime.now());
        return productVariantValueRepository.save(value);
    }

    public void deleteById(Long id, Long sellerId) {
        ProductVariantValue value = productVariantValueRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Value not found with id " + id));
        ProductVariant variant = productVariantRepository.findById(value.getVariant().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Variant not found with id " + value.getVariant().getId()));
        Product product = productRepository.findById(variant.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + variant.getProductId()));
        if (!product.getSellerId().equals(sellerId)) {
            throw new ResourceNotFoundException("You do not have permission to delete this value");
        }
        productVariantValueRepository.deleteById(id);
    }
}