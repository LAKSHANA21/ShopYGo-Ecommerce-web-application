package com.ecommerce.service;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Seller;
import com.ecommerce.model.SellerStatus;
import com.ecommerce.repository.SellerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SellerService {

    private final SellerRepository sellerRepository;

    public Seller addSeller(Seller seller) {
        seller.setCreatedAt(LocalDateTime.now());
        seller.setUpdatedAt(LocalDateTime.now());
        return sellerRepository.save(seller);
    }

    public Seller getSellerById(Long id) {
        return sellerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Seller not found with ID " + id));
    }

    public List<Seller> getAllSellers() {
        return sellerRepository.findAll();
    }

    public Seller updateSeller(Long id, Seller updatedSeller) {
        Seller existingSeller = getSellerById(id);
        existingSeller.setFirstName(updatedSeller.getFirstName());
        existingSeller.setLastName(updatedSeller.getLastName());
        existingSeller.setEmail(updatedSeller.getEmail());
        existingSeller.setPassword(updatedSeller.getPassword());
        existingSeller.setPhone(updatedSeller.getPhone());
        existingSeller.setStoreName(updatedSeller.getStoreName());
        existingSeller.setBusinessDetails(updatedSeller.getBusinessDetails());
        existingSeller.setAddressLine1(updatedSeller.getAddressLine1());
        existingSeller.setAddressLine2(updatedSeller.getAddressLine2());
        existingSeller.setCity(updatedSeller.getCity());
        existingSeller.setState(updatedSeller.getState());
        existingSeller.setPostalCode(updatedSeller.getPostalCode());
        existingSeller.setCountry(updatedSeller.getCountry());
        existingSeller.setContactNumber(updatedSeller.getContactNumber());
        existingSeller.setGstNumber(updatedSeller.getGstNumber());
        existingSeller.setBankDetails(updatedSeller.getBankDetails());
        existingSeller.setBusinessEmail(updatedSeller.getBusinessEmail());
        existingSeller.setStatus(updatedSeller.getStatus());
        existingSeller.setUpdatedAt(LocalDateTime.now());
        return sellerRepository.save(existingSeller);
    }

    public Seller updateSellerStatus(Long id, SellerStatus status) {
        Seller seller = getSellerById(id);
        seller.setStatus(status);
        seller.setUpdatedAt(LocalDateTime.now());
        return sellerRepository.save(seller);
    }

    public void deleteSeller(Long id) {
        Seller seller = getSellerById(id);
        sellerRepository.delete(seller);
    }

    public Optional<Seller> findByEmailOrMobile(String identifier) {
        Optional<Seller> sellerOpt = sellerRepository.findByEmail(identifier); // Check email first
        if (sellerOpt.isPresent()) {
            return sellerOpt;
        }
        sellerOpt = sellerRepository.findByBusinessEmail(identifier); // Then businessEmail
        if (sellerOpt.isPresent()) {
            return sellerOpt;
        }
        return sellerRepository.findByContactNumber(identifier); // Finally contactNumber
    }

    public Optional<Seller> findById(Long id) {
        return sellerRepository.findById(id);
    }
}