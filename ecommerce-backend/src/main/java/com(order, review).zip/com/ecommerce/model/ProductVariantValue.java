package com.ecommerce.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "product_variant_values")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductVariantValue {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "variant_id", nullable = false)
    private ProductVariant variant;

    @Column(nullable = false)
    private String value; // e.g., "Black", "Medium"

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}