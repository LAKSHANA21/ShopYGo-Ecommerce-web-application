package com.ecommerce.repository;

import com.ecommerce.model.Seller;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface SellerRepository extends JpaRepository<Seller, Long> {
    Optional<Seller> findByBusinessEmail(String businessEmail);
    Optional<Seller> findByContactNumber(String contactNumber);
    Optional<Seller> findByEmail(String email); // Added for login
}