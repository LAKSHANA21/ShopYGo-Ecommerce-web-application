package com.ecommerce.controller;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.*;
import com.ecommerce.payload.*;
import com.ecommerce.service.*;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductManagementController {

    private final ProductService productService;
    private final ProductVariantService productVariantService;
    private final ProductVariantValueService productVariantValueService;
    private final ProductImageService productImageService;
    private final SellerService sellerService;
    private final InventoryService inventoryService;

    @GetMapping
    public ResponseEntity<List<ProductRequest>> getAllProducts() {
        List<Product> products = productService.findAll();
        return ResponseEntity.ok(products.stream().map(this::mapToProductRequest).collect(Collectors.toList()));
    }

    @GetMapping("/search")
    public ResponseEntity<List<ProductRequest>> searchProducts(@RequestParam String query) {
        List<Product> products = productService.findAll().stream()
                .filter(p -> p.getName().toLowerCase().contains(query.toLowerCase()) ||
                        p.getDescription().toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(products.stream().map(this::mapToProductRequest).collect(Collectors.toList()));
    }

    @GetMapping("/{productId}")
    public ResponseEntity<ProductRequest> getProductById(@PathVariable Long productId) {
        Product product = productService.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + productId));
        return ResponseEntity.ok(mapToProductRequest(product));
    }

    @GetMapping("/category/{categoryId}")
    public ResponseEntity<List<ProductRequest>> getProductsByCategory(@PathVariable Long categoryId) {
        List<Product> products = productService.findByCategoryId(categoryId);
        return ResponseEntity.ok(products.stream().map(this::mapToProductRequest).collect(Collectors.toList()));
    }

    @GetMapping("/subcategory/{subcategoryId}")
    public ResponseEntity<List<ProductRequest>> getProductsBySubcategory(@PathVariable Long subcategoryId) {
        List<Product> products = productService.findBySubcategoryId(subcategoryId);
        return ResponseEntity.ok(products.stream().map(this::mapToProductRequest).collect(Collectors.toList()));
    }

    @PostMapping
    @PreAuthorize("hasRole('SELLER')")
    @Transactional
    public ResponseEntity<ProductRequest> createProduct(@RequestBody ProductRequest productRequest) {
        Long sellerId = getAuthenticatedSellerId();
        Product product = mapToProduct(productRequest, sellerId);
        Product savedProduct = productService.save(product);

        Inventory inventory = Inventory.builder()
                .productId(savedProduct.getId())
                .product(savedProduct)
                .quantity(productRequest.getQuantity() != null ? productRequest.getQuantity() : 0)
                .lowStockThreshold(productRequest.getLowStockThreshold() != null ? productRequest.getLowStockThreshold() : 10)
                .build();
        savedProduct.setInventory(inventory);
        inventoryService.save(inventory);
        inventoryService.updateStock(savedProduct.getId(), inventory.getQuantity());

        return ResponseEntity.ok(mapToProductRequest(savedProduct));
    }

    @PutMapping("/{productId}")
    @PreAuthorize("hasRole('SELLER')")
    @Transactional
    public ResponseEntity<?> updateProduct(
            @PathVariable Long productId,
            @RequestBody ProductRequest productRequest) {
        try {
            Long sellerId = getAuthenticatedSellerId();
            
            // Load the existing product within the transactional context
            Product existingProduct = productService.findById(productId)
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + productId));
            
            // Verify ownership
            if (!existingProduct.getSellerId().equals(sellerId)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(new ApiResponse(false, "You don't have permission to update this product"));
            }

         // Update only the fields that should be updatable
            if (productRequest.getName() != null) {
                existingProduct.setName(productRequest.getName());
            }
            if (productRequest.getDescription() != null) {
                existingProduct.setDescription(productRequest.getDescription());
            }
            if (productRequest.getActualPrice() != null) {
                existingProduct.setActualPrice(productRequest.getActualPrice());
            }
            if (productRequest.getMrp() != null) {
                existingProduct.setMrp(productRequest.getMrp());
            }
            if (productRequest.getMargin() != null) {
                existingProduct.setMargin(productRequest.getMargin());
            }
            if (productRequest.getThumbnailUrl() != null) {
                existingProduct.setThumbnailUrl(productRequest.getThumbnailUrl());
            }
            if (productRequest.getIsActive() != null) {
                existingProduct.setIsActive(productRequest.getIsActive());
            }
            if (productRequest.getInStock() != null) {
                existingProduct.setInStock(productRequest.getInStock());
            }
            if (productRequest.getSku() != null) {
                existingProduct.setSku(productRequest.getSku());
            }

            // Note: Typically you wouldn't allow updating these association IDs in an update operation
            // as it would effectively move the product to a different category
            // if (productRequest.getCategoryId() != null) {
//                 Category category = categoryRepository.findById(productRequest.getCategoryId())
//                         .orElseThrow(() -> new ResourceNotFoundException("Category not found"));
//                 existingProduct.setCategory(category);
            // }
            // 
            // if (productRequest.getSubcategoryId() != null) {
//                 Subcategory subcategory = subcategoryRepository.findById(productRequest.getSubcategoryId())
//                         .orElseThrow(() -> new ResourceNotFoundException("Subcategory not found"));
//                 existingProduct.setSubcategory(subcategory);
            // }

            // Also typically you wouldn't allow changing the seller ID
            // existingProduct.setSellerId() should not be updatable through this endpoint

            // Handle inventory updates separately
            if (productRequest.getQuantity() != null || productRequest.getLowStockThreshold() != null) {
                Inventory inventory = existingProduct.getInventory() != null ? 
                    existingProduct.getInventory() : 
                    new Inventory();
                
                if (productRequest.getQuantity() != null) {
                    inventory.setQuantity(productRequest.getQuantity());
                }
                if (productRequest.getLowStockThreshold() != null) {
                    inventory.setLowStockThreshold(productRequest.getLowStockThreshold());
                }
                
                inventory.setProduct(existingProduct);
                inventoryService.save(inventory);
            }

            Product updatedProduct = productService.save(existingProduct);
            return ResponseEntity.ok(mapToProductRequest(updatedProduct));
            
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
//            logger.error("Error updating product", e);
            return ResponseEntity.internalServerError()
                    .body(new ApiResponse(false, "Error updating product: " + e.getMessage()));
        }
    }

    @DeleteMapping("/{productId}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ApiResponse> deleteProduct(@PathVariable Long productId) {
        Long sellerId = getAuthenticatedSellerId();
        Product product = productService.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + productId));
        if (!product.getSellerId().equals(sellerId)) {
            throw new ResourceNotFoundException("You do not have permission to delete this product");
        }
        productService.deleteById(productId);
        return ResponseEntity.ok(new ApiResponse(true, "Product deleted successfully"));
    }

    // Variants, Values, and Images endpoints remain largely unchanged but should add where applicable
    // Example for one:
    @PostMapping("/{productId}/variants")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ProductVariantRequest> createProductVariant(
            @PathVariable Long productId,
            @RequestBody ProductVariantRequest variantRequest) {
        Long sellerId = getAuthenticatedSellerId();
        variantRequest.setProductId(productId);
        ProductVariant variant = mapToProductVariant(variantRequest);
        ProductVariant savedVariant = productVariantService.save(variant, sellerId);
        return ResponseEntity.ok(mapToProductVariantRequest(savedVariant));
    }

    private Long getAuthenticatedSellerId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new AccessDeniedException("User not authenticated");
        }
        
        String username;
        Object principal = authentication.getPrincipal();
        
        if (principal instanceof UserDetails) {
            username = ((UserDetails) principal).getUsername();
        } else if (principal instanceof String) {
            username = (String) principal;
        } else {
            throw new IllegalStateException("Unexpected principal type: " + principal.getClass());
        }
        
        Seller seller = sellerService.findByEmailOrMobile(username)
                .orElseThrow(() -> new ResourceNotFoundException("Seller not found with username: " + username));
        return seller.getId();
    }

    private ProductRequest mapToProductRequest(Product product) {
        ProductRequest request = new ProductRequest();
        request.setId(product.getId());
        request.setSellerId(product.getSellerId());
        request.setName(product.getName());
        request.setActualPrice(product.getActualPrice());
        request.setSellingPrice(product.getSellingPrice());
        request.setThumbnailUrl(product.getThumbnailUrl());
        request.setDescription(product.getDescription());
        request.setMrp(product.getMrp());
        request.setMargin(product.getMargin());
        request.setIsActive(product.getIsActive());
        request.setSku(product.getSku());
        request.setInStock(product.getInStock());
        request.setCategoryId(product.getCategory() != null ? product.getCategory().getId() : null);
        request.setCategoryName(product.getCategory() != null ? product.getCategory().getName() : null);
        request.setSubcategoryId(product.getSubcategory() != null ? product.getSubcategory().getId() : null);
        request.setSubcategoryName(product.getSubcategory() != null ? product.getSubcategory().getName() : null);
        request.setAverageRating(product.getAverageRating() != null ? product.getAverageRating().doubleValue() : 0.0);
        request.setReviewCount(product.getReviewCount() != null ? product.getReviewCount() : 0);
        request.setOrderCount(0); // Placeholder
        if (product.getInventory() != null) {
            request.setQuantity(product.getInventory().getQuantity());
            request.setLowStockThreshold(product.getInventory().getLowStockThreshold());
        }
        return request;
    }

    private Product mapToProduct(ProductRequest request, Long sellerId) {
        if (request.getCategoryId() == null || request.getSubcategoryId() == null) {
            throw new IllegalArgumentException("Category ID and Subcategory ID are required");
        }
        Product product = new Product();
        product.setSellerId(sellerId);
        product.setName(request.getName());
        product.setActualPrice(request.getActualPrice());
        product.setSellingPrice(request.getSellingPrice());
        product.setThumbnailUrl(request.getThumbnailUrl());
        product.setDescription(request.getDescription());
        product.setMrp(request.getMrp());
        product.setMargin(request.getMargin());
        product.setIsActive(request.getIsActive() != null ? request.getIsActive() : true);
        product.setSku(request.getSku());
        product.setInStock(request.getInStock() != null ? request.getInStock() : true);
        Category category = new Category();
        category.setId(request.getCategoryId());
        product.setCategory(category);
        Subcategory subcategory = new Subcategory();
        subcategory.setId(request.getSubcategoryId());
        product.setSubcategory(subcategory);
        return product;
    }

    private ProductVariantRequest mapToProductVariantRequest(ProductVariant variant) {
        ProductVariantRequest request = new ProductVariantRequest();
        request.setId(variant.getId());
        request.setProductId(variant.getProductId());
        request.setVariantType(variant.getVariantType());
        request.setValues(variant.getValues() != null ? variant.getValues().stream()
                .map(ProductVariantValue::getValue).collect(Collectors.toList()) : List.of());
        return request;
    }

    private ProductVariant mapToProductVariant(ProductVariantRequest request) {
        ProductVariant variant = new ProductVariant();
        variant.setProductId(request.getProductId());
        variant.setVariantType(request.getVariantType());
        return variant;
    }

    // Other mapping methods remain unchanged
}