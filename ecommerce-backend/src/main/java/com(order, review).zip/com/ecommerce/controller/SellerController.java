package com.ecommerce.controller;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Product;
import com.ecommerce.model.ProductImage;
import com.ecommerce.model.ProductVariant;
import com.ecommerce.model.Seller;
import com.ecommerce.payload.ApiResponse;
import com.ecommerce.service.ProductImageService;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.ProductVariantService;
import com.ecommerce.service.SellerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sellers")
@RequiredArgsConstructor
@CrossOrigin("*")
public class SellerController {

    private final SellerService sellerService;
    private final ProductService productService;
    private final ProductVariantService productVariantService;
    private final ProductImageService productImageService;

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<Seller> getSellerById(@PathVariable Long id) {
        return ResponseEntity.ok(sellerService.getSellerById(id));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<Seller> updateSeller(@PathVariable Long id, @RequestBody Seller seller) {
        return ResponseEntity.ok(sellerService.updateSeller(id, seller));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ApiResponse> deleteSeller(@PathVariable Long id) {
        sellerService.deleteSeller(id);
        return ResponseEntity.ok(new ApiResponse(true, "Seller deleted successfully"));
    }

    @GetMapping("/{id}/products")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<List<Product>> getSellerProducts(@PathVariable Long id) {
        return ResponseEntity.ok(productService.findBySellerId(id));
    }

    @PostMapping("/products")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<Product> createProduct(@RequestBody Product product, Authentication authentication) {
        Long sellerId = extractSellerIdFromAuth(authentication);
        product.setSellerId(sellerId);
        return ResponseEntity.ok(productService.save(product));
    }

    @PutMapping("/products/{productId}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<Product> updateProduct(@PathVariable Long productId, @RequestBody Product product, Authentication authentication) {
        Product existingProduct = productService.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + productId));
        Long sellerId = extractSellerIdFromAuth(authentication);
        if (!existingProduct.getSellerId().equals(sellerId)) {
            return ResponseEntity.status(403).body(null);
        }
        product.setId(productId);
        product.setSellerId(sellerId);
        return ResponseEntity.ok(productService.save(product));
    }

    @DeleteMapping("/products/{productId}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ApiResponse> deleteProduct(@PathVariable Long productId, Authentication authentication) {
        Product product = productService.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + productId));
        Long sellerId = extractSellerIdFromAuth(authentication);
        if (!product.getSellerId().equals(sellerId)) {
            return ResponseEntity.status(403).body(new ApiResponse(false, "Unauthorized"));
        }
        productService.deleteById(productId);
        return ResponseEntity.ok(new ApiResponse(true, "Product deleted successfully"));
    }

    @PostMapping("/products/{productId}/variants")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ProductVariant> createVariant(@PathVariable Long productId, @RequestBody ProductVariant variant, Authentication authentication) {
        Long sellerId = extractSellerIdFromAuth(authentication);
        variant.setProductId(productId);
        return ResponseEntity.ok(productVariantService.save(variant, sellerId));
    }

    @PutMapping("/products/variants/{variantId}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ProductVariant> updateVariant(@PathVariable Long variantId, @RequestBody ProductVariant variant, Authentication authentication) {
        Long sellerId = extractSellerIdFromAuth(authentication);
        ProductVariant existingVariant = productVariantService.findById(variantId)
                .orElseThrow(() -> new ResourceNotFoundException("Variant not found with id " + variantId));
        variant.setId(variantId);
        variant.setProductId(existingVariant.getProductId());
        return ResponseEntity.ok(productVariantService.save(variant, sellerId));
    }

    @DeleteMapping("/products/variants/{variantId}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ApiResponse> deleteVariant(@PathVariable Long variantId, Authentication authentication) {
        Long sellerId = extractSellerIdFromAuth(authentication);
        productVariantService.deleteById(variantId, sellerId);
        return ResponseEntity.ok(new ApiResponse(true, "Variant deleted successfully"));
    }

    @PostMapping("/products/{productId}/images")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ProductImage> createImage(@PathVariable Long productId, @RequestBody ProductImage image, Authentication authentication) {
        Long sellerId = extractSellerIdFromAuth(authentication);
        image.setProductId(productId);
        return ResponseEntity.ok(productImageService.save(image, sellerId));
    }

    @PutMapping("/products/images/{imageId}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ProductImage> updateImage(@PathVariable Long imageId, @RequestBody ProductImage image, Authentication authentication) {
        Long sellerId = extractSellerIdFromAuth(authentication);
        ProductImage existingImage = productImageService.findById(imageId)
                .orElseThrow(() -> new ResourceNotFoundException("Image not found with id " + imageId));
        image.setId(imageId);
        image.setProductId(existingImage.getProductId());
        return ResponseEntity.ok(productImageService.save(image, sellerId));
    }

    @DeleteMapping("/products/images/{imageId}")
    @PreAuthorize("hasRole('SELLER')")
    public ResponseEntity<ApiResponse> deleteImage(@PathVariable Long imageId, Authentication authentication) {
        Long sellerId = extractSellerIdFromAuth(authentication);
        productImageService.deleteById(imageId, sellerId);
        return ResponseEntity.ok(new ApiResponse(true, "Image deleted successfully"));
    }

    private Long extractSellerIdFromAuth(Authentication authentication) {
        String email = authentication.getName();
        return sellerService.findByEmailOrMobile(email)
                .map(Seller::getId)
                .orElseThrow(() -> new ResourceNotFoundException("Seller not found"));
    }
}