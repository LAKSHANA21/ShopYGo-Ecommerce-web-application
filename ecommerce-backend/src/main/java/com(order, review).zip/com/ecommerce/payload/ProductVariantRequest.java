package com.ecommerce.payload;

import lombok.Data;

import java.util.List;

@Data
public class ProductVariantRequest {
    private Long id;
    private Long productId;
    private String variantType; // e.g., "Color", "Size"
    private List<String> values; // e.g., ["Black", "White", "Blue"]
}