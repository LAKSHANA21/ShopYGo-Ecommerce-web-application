package com.ecommerce.repository;

import com.ecommerce.model.CartItem;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {
	List<CartItem> findByCartId(Long cartId); // New method to find items by cartId
	
	// Delete only if item exists AND belongs to the specified cart
	@Modifying
    @Query("DELETE FROM CartItem ci WHERE ci.id = :itemId AND ci.cartId = :cartId")
    int deleteByIdAndCartId(@Param("itemId") Long itemId, 
                          @Param("cartId") Long cartId);
}
