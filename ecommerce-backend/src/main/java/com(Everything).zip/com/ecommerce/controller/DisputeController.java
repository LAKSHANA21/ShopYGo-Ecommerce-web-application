package com.ecommerce.controller;

import com.ecommerce.exception.ResourceNotFoundException;
import com.ecommerce.model.Dispute;
import com.ecommerce.service.DisputeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/disputes")
@RequiredArgsConstructor
public class DisputeController {

    private final DisputeService disputeService;

    @GetMapping
    public ResponseEntity<List<Dispute>> getAllDisputes() {
        List<Dispute> disputes = disputeService.findAll();
        return ResponseEntity.ok(disputes);
    }

    @PostMapping
    public ResponseEntity<Dispute> createDispute(@RequestBody Dispute dispute) {
        dispute.setCreatedAt(LocalDateTime.now());
        Dispute savedDispute = disputeService.save(dispute);
        return ResponseEntity.ok(savedDispute);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Dispute> updateDispute(@PathVariable Long id, @RequestBody Dispute dispute) {
        Optional<Dispute> existingDisputeOpt = disputeService.findById(id);
        if (existingDisputeOpt.isEmpty()) {
            throw new ResourceNotFoundException("Dispute not found with id " + id);
        }
        Dispute existingDispute = existingDisputeOpt.get();
        existingDispute.setStatus(dispute.getStatus());
        existingDispute.setResolvedAt(LocalDateTime.now());
        Dispute updatedDispute = disputeService.save(existingDispute);
        return ResponseEntity.ok(updatedDispute);
    }
}
