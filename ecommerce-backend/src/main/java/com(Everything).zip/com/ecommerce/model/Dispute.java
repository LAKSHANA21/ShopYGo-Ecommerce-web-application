package com.ecommerce.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "disputes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Dispute {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long orderId;
    private Long userId;
    private Long sellerId;
    private String disputeReason;
    private String status; // open, resolved, rejected
    
    private LocalDateTime createdAt;
    private LocalDateTime resolvedAt;
}
