package com.ecommerce.service;

import com.ecommerce.model.Review;
import com.ecommerce.repository.ReviewRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;

    public Review addOrUpdateReview(Review review) {
        // Check if user already has a review for this product
        Review existingReview = reviewRepository.findByProductIdAndUserId(
                review.getProductId(), 
                review.getUserId()
        ).orElse(null);

        if (existingReview != null) {
            // Update existing review
            existingReview.setRating(review.getRating());
            existingReview.setComment(review.getComment());
            existingReview.setUpdatedAt(LocalDateTime.now());
            return reviewRepository.save(existingReview);
        } else {
            // Create new review
            review.setCreatedAt(LocalDateTime.now());
            review.setUpdatedAt(LocalDateTime.now());
            return reviewRepository.save(review);
        }
    }

    public List<Review> getReviewsByProductId(Long productId) {
        return reviewRepository.findByProductId(productId);
    }

    public Review getReviewByProductAndUser(Long productId, Long userId) {
        return reviewRepository.findByProductIdAndUserId(productId, userId)
                .orElse(null);
    }

    @Transactional
    public void deleteReview(Long reviewId, Long userId) {
        reviewRepository.deleteByIdAndUserId(reviewId, userId);
    }
}