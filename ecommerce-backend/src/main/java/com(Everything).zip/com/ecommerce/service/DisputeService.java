package com.ecommerce.service;

import com.ecommerce.model.Dispute;
import com.ecommerce.repository.DisputeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class DisputeService {

    private final DisputeRepository disputeRepository;
    
    public List<Dispute> findAll() {
        return disputeRepository.findAll();
    }
    
    public Optional<Dispute> findById(Long id) {
        return disputeRepository.findById(id);
    }
    
    public Dispute save(Dispute dispute) {
        return disputeRepository.save(dispute);
    }
}
